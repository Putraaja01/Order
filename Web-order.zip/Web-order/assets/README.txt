Folder assets untuk gambar, video, favicon, atau file media website.
